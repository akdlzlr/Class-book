package edu.iot.Scorpio.command;

import static org.junit.Assert.*;

import org.junit.Test;

public class RegionCommandTest {
	
	
	@Test
	public void testRegionCommand() throws Exception {
		RegionCommand rc = new RegionCommand();
		rc.execute();
		
	}
}
