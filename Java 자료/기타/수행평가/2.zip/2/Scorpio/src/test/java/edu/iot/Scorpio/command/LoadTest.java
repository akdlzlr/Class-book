package edu.iot.Scorpio.command;

import static org.junit.Assert.*;

import org.junit.Test;

public class LoadTest {
	@Test
	public void testLoad() throws Exception {
		
	}
}
